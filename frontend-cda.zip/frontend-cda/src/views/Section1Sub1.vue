<!-- src/views/Section1Sub1.vue -->
<template>
    <div>
      <h1>Sección 1 - Subsección 1.1</h1>
      <p>Contenido de la subsección 1.1</p>
    </div>
  </template>
  
  <script setup lang="ts">
  // Puedes agregar lógica específica aquí si es necesario
  </script>
  
  <style scoped>
  /* Estilos específicos para esta vista */
  </style>
  